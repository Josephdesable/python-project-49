### Hexlet tests and linter status:
[![Actions Status](https://github.com/Josephdesable/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Josephdesable/python-project-49/actions)
<a href="https://codeclimate.com/github/Josephdesable/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/5b2ec94e319759b377da/maintainability" /></a>
https://asciinema.org/a/iyaBDqyZqoEpeJTkhzQpVRoUD
